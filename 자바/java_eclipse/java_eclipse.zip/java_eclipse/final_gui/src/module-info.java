/**
 * 
 */
/**
 * 
 */
module final_gui {
	requires java.desktop;
}