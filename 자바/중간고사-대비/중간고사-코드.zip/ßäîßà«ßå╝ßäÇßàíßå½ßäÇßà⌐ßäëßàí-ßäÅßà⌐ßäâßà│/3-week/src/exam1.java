public class exam1 {
    public static void main(String[] arg){
        int n[][] = {{1}, {1,2,3}, {1}, {1,2,3,4}, {1,2}};
        System.out.println(n[0][0] + " ");
        System.out.print(n[1][0] + " " + n[1][1] + " "+ n[1][2] + " \n");
        System.out.println(n[2][0] + " ");
        System.out.print(n[3][0] + " " + n[3][1] + " "+ n[3][2] + " " + n[3][3] + " \n");
        System.out.print(n[4][0] + " " +n[4][1]+ " ");
    }
}
