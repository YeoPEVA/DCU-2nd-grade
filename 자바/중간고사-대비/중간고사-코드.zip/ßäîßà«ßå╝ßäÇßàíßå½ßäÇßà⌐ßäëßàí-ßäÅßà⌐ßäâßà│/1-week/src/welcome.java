public class welcome {
    public static void main(String[] args) {
        System.out.println("Welcome!!");
        System.out.println("Welcome to Java world.");

    }
}
