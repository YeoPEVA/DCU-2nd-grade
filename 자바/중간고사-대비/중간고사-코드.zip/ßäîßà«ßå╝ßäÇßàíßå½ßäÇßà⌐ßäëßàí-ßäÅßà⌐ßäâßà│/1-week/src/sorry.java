public class sorry {
    public static void main(String[] args) {
        System.out.println("Sorry~~");
        System.out.println("I'm sorry that is so fun~~");
    }
}
